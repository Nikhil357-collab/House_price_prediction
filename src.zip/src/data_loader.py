import pandas as pd
import numpy as np

np.random.seed(42)
n = 1000

df = pd.DataFrame({
    "LotArea": np.random.randint(2000, 15000, n),
    "OverallQual": np.random.randint(1, 10, n),
    "OverallCond": np.random.randint(1, 10, n),
    "YearBuilt": np.random.randint(1950, 2022, n),
    "GrLivArea": np.random.randint(500, 4000, n),
    "TotalBsmtSF": np.random.randint(0, 2000, n),
    "GarageCars": np.random.randint(0, 4, n),
    "GarageArea": np.random.randint(0, 1000, n),
    "FullBath": np.random.randint(1, 4, n),
    "HalfBath": np.random.randint(0, 2, n),
    "Neighborhood": np.random.choice(["A","B","C"], n),
    "HouseStyle": np.random.choice(["1Story","2Story"], n),
    "BldgType": np.random.choice(["1Fam","Duplex"], n),
    "MSZoning": np.random.choice(["RL","RM"], n)
})

# Target
df["SalePrice"] = (
    df["GrLivArea"] * 120 +
    df["OverallQual"] * 10000 +
    df["GarageArea"] * 50 +
    df["FullBath"] * 5000 +
    np.random.randint(-20000, 20000, n)
)
print(df.head())
df.to_csv("House_Price_PredictionModel/data/houses.csv", index=False)
print("Dataset created!")