import joblib
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor

from preprocess import preprocess

X, y = preprocess()

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Models
rf = RandomForestRegressor(n_estimators=200)
xgb = XGBRegressor(objective="reg:squarederror")

rf.fit(X_train, y_train)
xgb.fit(X_train, y_train)

def evaluate(model):
    pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, pred))
    mae = mean_absolute_error(y_test, pred)
    r2 = r2_score(y_test, pred)
    return rmse, mae, r2

rf_metrics = evaluate(rf)
xgb_metrics = evaluate(xgb)

print("RF:", rf_metrics)
print("XGB:", xgb_metrics)

# Save best
best = xgb if xgb_metrics[2] > rf_metrics[2] else rf

joblib.dump(best, "House_Price_PredictionModel/models/model.pkl")
joblib.dump(X.columns.tolist(), "House_Price_PredictionModel/models/features.pkl")

print("Model saved!")