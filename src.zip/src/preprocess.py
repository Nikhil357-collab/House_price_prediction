import pandas as pd

def preprocess():
    df = pd.read_parquet("House_Price_PredictionModel/data/houses.parquet")

    # One-hot encoding
    df = pd.get_dummies(df, drop_first=True)

    X = df.drop("SalePrice", axis=1)
    y = df["SalePrice"]

    return X, y